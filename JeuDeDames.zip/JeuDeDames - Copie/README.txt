Le rendu doit contenir les fichiers/dossier suivant :
	-dossier : JeuDeDames
	-fichier : README.txt, Trace d'exécution tgomes mbenyoub.pdf

PS : Le JUnit est présent directement dans le fichier du programme (à ouvrir avec Intellij).