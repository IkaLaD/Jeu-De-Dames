import java.sql.PseudoColumnUsage;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class JeuDeDame
{
    /***
     *
     * @param taillePlateau
     *
     * Crée le plateau de jeu en position de début de partie.
     *
     */
    public static int[][] initalisation(int taillePlateau)
    {
        int[][] plateau = new int[taillePlateau][taillePlateau];

        for (int ligne = 0 ; ligne < 4 ; ligne++)
            for (int colonne = 0; colonne < taillePlateau; colonne++)
                if ((ligne+colonne)%2 != 0)
                    plateau[ligne][colonne] = 1;

        for (int ligne = taillePlateau-1 ; ligne >= taillePlateau - 4 ; ligne--)
            for (int colonne = 0; colonne < taillePlateau; colonne++)
                if ((ligne+colonne)%2 != 0)
                    plateau[ligne][colonne] = 3;

        return plateau;
    }

    /**
     *    -------- JUNIT DISPONIBLE ---------
     *
     * @param plateau       plateau du jeu
     * @param depart        position départ
     * @param arrivee       position d'arrivée
     * @param couleur       couleur du joueur qui joue
     * @param peuPrendre    si le pion fait une prise ou un déplacement simple
     *
     * Déplace le pion en faisant une prise ou non (booléen peutPrendre).
     *
     */
    public static void deplacePion(int[][] plateau, Case depart, Case arrivee, int couleur, boolean peuPrendre)
    {
        if (peuPrendre)
        {
            Case prendre = recupPositionPionPris(plateau,depart,arrivee,couleur);
            plateau[prendre.getLigne()][prendre.getColonne()] = 0;
        }

        plateau[arrivee.getLigne()][arrivee.getColonne()] = plateau[depart.getLigne()][depart.getColonne()];
        plateau[depart.getLigne()][depart.getColonne()] = 0;
    }

    /**
     *
     * @param plateau   plateau du jeu
     * @param depart    position départ
     * @param arrivee   position d'arrivée
     * @param couleur   couleur du joueur qui joue
     *
     * Retourne la case du pion qui doit être pris.
     *
     */
    public static Case recupPositionPionPris(int[][] plateau, Case depart, Case arrivee, int couleur)
    {
        boolean pionTrouve = false;
        Case pionPris;

        int startX = depart.getColonne(),x = startX,finX = arrivee.getColonne();
        int startY = depart.getLigne(),y = startY,finY = arrivee.getLigne();

        int directionX = startX > finX ? -1 : 1;
        int directionY = startY > finY ? -1 : 1;

        do
        {
            x += directionX;
            y += directionY;

            if (!positionVide(plateau,x,y) && recupCouleur(plateau,x,y) != couleur)
                pionTrouve = true;

        } while ((x != finX && y != finY) && !pionTrouve);

        pionPris = new Case(x,y);

        return pionPris;
    }


    /**
     *
     * @param plateau   plateau du jeu
     * @param depart     position départ
     * @param couleur   couleur du joueur qui joue
     *
     * Permet de savoir si le pion sur la case début permet de faire la/l'une de(s) prise(s) la/les plus longue(s).
     *
     */
    public static boolean estLunDesPlusLongChemin(int[][] plateau, Case depart, int couleur)
    {
        List<Case> listePions = recupListePositionPions(plateau,couleur);
        int[] longueurChemins = new int[listePions.size()];

        for (int i = 0 ; i < listePions.size() ; i++)
        {
            int typePion = plateau[listePions.get(i).getLigne()][listePions.get(i).getColonne()];
            longueurChemins[i] = recupererLongueurPlusGrandChemin(copie(plateau), listePions.get(i), couleur, typePion);
        }

        int maximum = longueurChemins[0];
        for(int i = 1 ; i < longueurChemins.length ; i++)
        {
            if(maximum<longueurChemins[i])
                maximum=longueurChemins[i];
        }

        int typePion = plateau[depart.getLigne()][depart.getColonne()];
        if(recupererLongueurPlusGrandChemin(copie(plateau), depart, couleur, typePion)==maximum)
            return true;
        return false;
    }

    /**
     *
     * @param plateau   plateau du jeu
     * @param depart     position départ
     * @param couleur   couleur du joueur qui joue
     *
     * Permet de savoir combien de pion peuvent etre pris par le pion/dame sur la case debut
     *
     */
    public static int recupererLongueurPlusGrandChemin(int[][] plateau, Case depart, int couleur, int typePion)
    {
        int plusGrandChemin = 0;
        int tmp = 0;

        plateau[depart.getLigne()][depart.getColonne()]=typePion;
        if (peutPrendre(plateau,depart,couleur))
        {
            HashMap<Case, Case> prochainePosition = recupProchainePosApresPionPris(plateau,depart,couleur);

            plateau[depart.getLigne()][depart.getColonne()]=0;
            for (Case fin : prochainePosition.keySet())
            {
                int[][] plateautmp = copie(plateau);

                plateautmp[prochainePosition.get(fin).getLigne()][prochainePosition.get(fin).getColonne()] = 0;
                tmp += recupererLongueurPlusGrandChemin((plateautmp), fin, couleur, typePion) + 1;

                if (tmp > plusGrandChemin)
                    plusGrandChemin = tmp;
                tmp = 0;
            }
        }

        return plusGrandChemin;
    }

    /***
     *
     * @param plateau   plateau du jeu
     * @param depart     position départ
     * @param couleur   couleur du joueur qui joue
     * @param typePion  pion ou dame
     *
     * Permet de renvoyer la/les prochaine(s) case(s) à laquelle(s) se rendre pour effectuer le chemin le plus long.
     */
    public static List<Case> recupererProchaineCasePlusGrandChemin(int[][] plateau, Case depart, int couleur, int typePion)
    {
        List<Case> plusGrandChemin = new ArrayList<>();

        int LongueurPlusGrandChemin = 0;
        int tmp = 0;

        plateau[depart.getLigne()][depart.getColonne()]=typePion;
        if (peutPrendre(plateau,depart,couleur))
        {
            HashMap<Case, Case> prochainePosition = recupProchainePosApresPionPris(plateau,depart,couleur);

            plateau[depart.getLigne()][depart.getColonne()]=0;
            for (Case fin : prochainePosition.keySet())
            {
                int[][] plateautmp = copie(plateau);

                plateautmp[prochainePosition.get(fin).getLigne()][prochainePosition.get(fin).getColonne()] = 0;
                tmp += recupererLongueurPlusGrandChemin((plateautmp), fin, couleur, typePion) + 1;

                if (tmp > LongueurPlusGrandChemin) {
                    LongueurPlusGrandChemin = tmp;
                    plusGrandChemin.clear();
                    plusGrandChemin.add(fin);
                }
                else if(tmp == LongueurPlusGrandChemin)
                    plusGrandChemin.add(fin);

                tmp = 0;
            }
        }

        return plusGrandChemin;
    }

    /***
     *
     * @param plateau   plateau du jeu
     * @param depart    position départ
     * @param couleur   couleur du joueur qui joue
     *
     * Récupère toutes la/les case(s) du/des pion(s) que le joueur peut manger depuis la position départ, et la/les position(s) d'arrivée(s) après la/les prise(s).
     *
     */
    public static HashMap<Case, Case> recupProchainePosApresPionPris(int[][] plateau, Case depart, int couleur)
    {
        HashMap<Case, Case> listePosition = new HashMap<>();
        boolean stop = false;
        int debutX = depart.getColonne();
        int debutY = depart.getLigne();
        int prochainX,prochainY;
        Case prochainePos;
        Case pionAManger;


        if (estUneDame(plateau, depart))
        {
            for (int ligne = -1 ; ligne <= 1 ; ligne += 2)
            {
                for (int colonne = -1; colonne <= 1; colonne += 2) {
                    prochainX = debutX + colonne;
                    prochainY = debutY + ligne;
                    int cpt=0;

                    do {
                        if (coCorrecte(prochainX, prochainY))
                        {
                            if (!positionVide(plateau, prochainX, prochainY))
                            {
                                if (recupCouleur(plateau, prochainX, prochainY) != couleur) {
                                    pionAManger = new Case(prochainX, prochainY);
                                    prochainX += colonne;
                                    prochainY += ligne;
                                    prochainePos = new Case(prochainX, prochainY);

                                    if (positionVide(plateau, prochainePos)) {
                                        listePosition.put(prochainePos, pionAManger);
                                        prochainX += colonne;
                                        prochainY += ligne;
                                        prochainePos = new Case(prochainX, prochainY);

                                        while (coCorrecte(prochainX, prochainY) && positionVide(plateau, prochainePos)) {
                                            listePosition.put(prochainePos, pionAManger);
                                            prochainX += colonne;
                                            prochainY += ligne;
                                            prochainePos = new Case(prochainX, prochainY);
                                        }
                                        stop = true;
                                    } else {
                                        stop = true;
                                    }
                                } else {
                                    stop = true;
                                }
                            }
                        }
                        else {
                            stop = true;
                        }

                        prochainX += colonne;
                        prochainY += ligne;
                        cpt++;

                    } while (cpt < 10 && !stop);

                    stop = false;
                }
            }

        }
        else
        {
            for (int ligne = -1 ; ligne <= 1 ; ligne += 2)
            {
                for (int colonne = -1 ; colonne <= 1 ; colonne += 2)
                {
                    prochainX = debutX + colonne;
                    prochainY = debutY + ligne;

                    if (coCorrecte(prochainX,prochainY) && !positionVide(plateau,prochainX,prochainY) && recupCouleur(plateau,prochainX,prochainY) != couleur )
                    {
                        pionAManger = new Case(prochainX, prochainY);
                        prochainX+=colonne;
                        prochainY+=ligne;
                        prochainePos = new Case(prochainX,prochainY);

                        if (coCorrecte(prochainX,prochainY) && positionVide(plateau,prochainePos))
                            listePosition.put(prochainePos, pionAManger);
                    }
                }
            }
        }

        return listePosition;
    }

    /**
     *
     * @param plateau plateay
     *
     * Crée un copie du plateau.
     *
     */
    public static int[][] copie(int[][] plateau)
    {
        int[][] copie = new int[plateau.length][plateau.length];

        for(int i = 0 ; i < copie.length ; i++)
        {
            for(int j = 0 ; j < copie[i].length ; j++)
            {
                copie[i][j] = plateau[i][j];
            }
        }
        return copie;
    }

    /**
     *    -------- JUNIT FAIT ---------+
     *
     * @param plateau   plateau du jeu
     * @param depart    position depart
     * @param couleur   couleur du joueur qui joue
     *
     * permet de savoir si un pion peux se déplacer ou non (libre de mouvement).
     *
     */
    public static boolean peutBouger(int[][] plateau, Case depart, int couleur)
    {
        boolean estUneDame = estUneDame(plateau,depart);
        boolean peuBouger = false;
        int[] direction;

        int debutX = depart.getColonne(),debutY = depart.getLigne(),prochaineX,prochainY;
        int directionX = 0,directionY = 0;

        if (estUneDame)
        {
            direction = new int[]{-1,1};

            while (directionY < direction.length && !peuBouger)
            {
                while (directionX < direction.length && !peuBouger)
                {
                    prochaineX = debutX+direction[directionX];
                    prochainY = debutY+direction[directionY];

                    if (coCorrecte(prochaineX,prochainY) && positionVide(plateau,prochaineX,prochainY))
                        peuBouger = true;
                    directionX++;
                }
                directionY++;
                directionX = 0;
            }
        }
        else
        {
            direction = new int[]{couleur == 1 ? 1 : -1};

            prochainY = debutY+direction[0];

            if (coCorrecte(debutX-1,prochainY) && positionVide(plateau,debutX-1,prochainY) || coCorrecte(debutX+1,prochainY) && positionVide(plateau,debutX+1,prochainY))
                peuBouger = true;
        }

        return peuBouger;
    }


    /**
     *    -------- JUNIT FAIT ---------
     *
     * @param plateau   plateau du jeu
     * @param couleur   couleur des pions à récupérés.
     *
     * parcour le tableau et stock les coordonnées des pions de la couleur souhaitée dans une liste.
     *
     */
    public static List<Case> recupListePositionPions(int[][] plateau, int couleur)
    {
        List<Case> listePosition = new ArrayList<>();
        for (int ligne = 0 ; ligne < 10 ; ligne++)
            for (int colonne = 0 ; colonne < 10 ; colonne++)
                if (recupCouleur(plateau, colonne, ligne) == couleur)
                {
                    listePosition.add(new Case(colonne, ligne));
                }
        return listePosition;
    }

    /**
     *    -------- JUNIT FAIT ---------
     *
     * @param plateau   plateau du jeu
     * @param couleur   couleur qu'on souhaite vérifier
     *
     * Parcours les pions de la couleur souhaitée et vérifie si l'un d'eux au moins peuvent prendre un pion adverse.
     *
     */
    public static boolean nePeutPasPrendre(int[][] plateau, int couleur)
    {
        boolean peuPrendre = false;
        int cpt = 0;
        List<Case> listeCoPions = recupListePositionPions(plateau,couleur);

        while (cpt < listeCoPions.size() && !peuPrendre)
            peuPrendre = peutPrendre(plateau, listeCoPions.get(cpt++), couleur);

        return !peuPrendre;
    }

    /***
     *
     * @param plateau   plateau du jeu
     *
     * Vérifie si la partie est fini ou non.
     */
    public static boolean partieFini(int[][] plateau)
    {
        int cptPionNoir=0;
        int cptPionBlanc=0;
        for(int i = 0 ; i < plateau.length ; i++)
        {
            for(int j = 0 ; j < plateau[i].length ; j++)
            {
                if(plateau[i][j]==1 || plateau[i][j]==2)
                    cptPionNoir++;
                else if(plateau[i][j]!=0)
                    cptPionBlanc++;
            }
        }

        return (cptPionBlanc == 0 || cptPionNoir==0);
    }

    public static void quiAGagne(int[][] plateau, List<String> pseudo){
        String vainceur="";
        int couleur=0;
        int cptblanc=0;
        int cptnoir=0;
        for(int i = 0 ; i < plateau.length ; i++){
            for(int j = 0 ; j < plateau[i].length ; j++){
                if(plateau[i][j]!=0){
                    if(plateau[i][j]==1 || plateau[i][j]==2) {
                        cptblanc++;
                        couleur = 1;
                        vainceur = pseudo.get(0);
                    }
                    else{
                        cptnoir++;
                        couleur = 2;
                        vainceur=pseudo.get(1);
                    }
                }
            }
        }
        DeroulePartie.espace(30);

        if(cptblanc!=0 && cptnoir!=0) {
            Affichage.plateau(plateau, 1);
            System.out.println("PARTIE FINI : égalité ! (vous avez jouez plus de 25 coups sans jamais faire de prise).");
        }
        else{
            Affichage.plateau(plateau, couleur);
            System.out.println("PARTI FINI : Le vainceur est : " + vainceur + " !");
        }
    }

    /**
     *    -------- JUNIT FAIT ---------
     *
     * @param plateau   plateau du jeu
     * @param depart    position du pion
     * @param couleur   couleur du pion
     *
     * Verifie si le pion peut faire une prise ou non.
     *
     */
    public static boolean peutPrendre(int[][] plateau, Case depart, int couleur)
    {
        boolean peuPrendre = false;
        boolean obstaclePresent;

        int debutX = depart.getColonne(), x = debutX, prochainX;
        int debutY = depart.getLigne(), y = debutY, prochainY;
        int distanceMax = plateau[y][x]%2 == 0 ? 10:1;
        int ligne = 0, colonne = 0;
        int distance;
        int[] direction = {-1,1};

        while (ligne < direction.length && !peuPrendre)
        {
            while (colonne < direction.length && !peuPrendre)
            {
                distance = 0;
                x = debutX;
                y = debutY;
                obstaclePresent = false;

                while (distance < distanceMax && coCorrecte(x,y) && !obstaclePresent && !peuPrendre)
                {
                    x += direction[colonne];
                    y += direction[ligne];

                    if (coCorrecte(x,y))
                    {
                        if (!positionVide(plateau,x,y))
                        {
                            if (recupCouleur(plateau,x,y) != couleur)
                            {
                                prochainX = x+direction[colonne];
                                prochainY = y+direction[ligne];

                                if (coCorrecte(prochainX,prochainY) && positionVide(plateau,prochainX,prochainY))
                                {
                                    peuPrendre = true;
                                }
                                else
                                {
                                    obstaclePresent = true;
                                }
                            }
                            else
                            {
                                obstaclePresent = true;
                            }
                        }
                    }
                    else
                    {
                        obstaclePresent = true;
                    }
                    distance++;
                }
                colonne++;
            }
            colonne =0;
            ligne++;
        }
        return peuPrendre;
    }

    /***
     *
     * @param plateau   plateau du jeu
     * @param depart    position de départ
     * @param arrivee   position d'arrivée
     * @param couleur   couleur du pion
     *
     * Vérifie si le pion/la dame fait un déplacement logique (diagonale, distance).
     *
     */
    public static boolean deplacementLogique(int[][] plateau, Case depart, Case arrivee, int couleur)
    {
        if(!estUneDame(plateau, depart))
        {
            int directionY = arrivee.getLigne() > depart.getLigne() ? -1 : 1;
            if(peutPrendre(plateau, depart, couleur)) {
                return estLePionCorrecte(plateau, depart, couleur) && Math.abs(arrivee.getLigne() - depart.getLigne()) == 2 && Math.abs(arrivee.getColonne() - depart.getColonne()) == 2;
            }
            else{
                return estLePionCorrecte(plateau, depart, couleur) && (directionY > 0 && couleur == 2 || directionY < 0 && couleur == 1) && (Math.abs(arrivee.getLigne() - depart.getLigne()) == 1) && (Math.abs(arrivee.getColonne() - depart.getColonne()) == 1);
            }
        }
        else
        {
            int directionY=1;
            int directionX=1;

            int x = depart.getColonne();
            int y = depart.getLigne();

            for(int i = -1 ; i <= 1 ; i+=2){
                for(int j = -1 ; j <= 1 ; j+=2){
                    while(x+(i*directionX) >= 0 && x+(i*directionX) < 10 && y+(j*directionY) >= 0 && y+(j*directionY) < 10)
                    {
                        if(x+(i*directionX) == arrivee.getColonne() && y+(j*directionY) == arrivee.getLigne())
                        {
                            return estLePionCorrecte(plateau, depart, couleur);
                        }
                        directionX++;
                        directionY++;
                    }
                    directionX=1;
                    directionY=1;
                }
            }
        }

        return false;
    }

    /**
     *
     * @param plateau
     *
     * Permet de transformer tout les pions se trouvant sur les extrémitées du plateau en dame.
     *
     */
    public static void transformationDame(int[][] plateau)
    {
        for(int i = 0 ; i < plateau[0].length ; i++)
        {
            if(plateau[0][i]==3)
                plateau[0][i]=4;
        }
        for(int i = 0 ; i < plateau[9].length ; i++)
        {
            if(plateau[9][i]==1)
                plateau[9][i]=2;
        }
    }


    public static boolean estLePionCorrecte(int[][] plateau, Case c, int couleur)
    {
        return recupCouleur(plateau,c) == couleur;
    }
    public static int quelEstLePion(int[][] plateau, Case c){
        return plateau[c.getLigne()][c.getColonne()];
    }
    public static boolean estUneDame(int[][] plateau, Case c)
    {
        return plateau[c.getLigne()][c.getColonne()]%2 == 0 && plateau[c.getLigne()][c.getColonne()] != 0;
    }
    public static boolean positionValide(Case fin)
    {
        return  (fin.getColonne()+fin.getLigne())%2 != 0 && coCorrecte(fin.getColonne(),fin.getLigne());
    }
    public static boolean coCorrecte(int x, int y)
    {
        return x >= 0  && x < 10 && y >= 0 && y < 10 ;
    }
    public static boolean estSurLaMemeDiagonale(Case p1, Case p2)
    {
        return Math.abs(p1.getColonne()-p2.getLigne()) == Math.abs(p1.getLigne()-p2.getLigne());
    }
    public static int recupCouleur(int[][] plateau, Case c)
    {
        int pion = plateau[c.getLigne()][c.getColonne()];
        return pion == 0 ? 0 : pion <= 2 ? 1 : 2;
    }
    public static int recupCouleur(int[][] plateau, int x, int y)
    {
        int pion = plateau[y][x];
        return pion == 0 ? 0 : pion <= 2 ? 1 : 2;
    }
    public static boolean positionVide(int[][] plateau, Case co)
    {
        return plateau[co.getLigne()][co.getColonne()] == 0;
    }

    public static boolean positionVide(int[][] plateau, int x, int y)
    {
        return plateau[y][x] == 0;
    }
}