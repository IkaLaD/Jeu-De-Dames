public class Affichage {
    public static void plateau(int[][] plateau, int couleur) {
        // Piece à (potentiellement) afficher.
        char pionnoir = '●';
        char pionblanc = '○';
        char damenoire = '■';
        char dameblanche = '□';

        // Couleur (rouge et bleue) + Reset couleur
        String ANSI_COLOR;
        String ANSI_RESET = "\u001B[0m"; // Reset couleur
        if (couleur == 1) ANSI_COLOR = "\u001B[34m"; // Bleu si joueur 0
        else ANSI_COLOR = "\u001B[31m"; // Rouge si joueur 1

        // Plateau :
        System.out.print(ANSI_COLOR + "■  ");                    // Affichage des numéros de colonnes
        for (int largeur = 0; largeur < plateau.length; largeur++)
            System.out.print((largeur) + "  ");

        System.out.println("■" + ANSI_RESET);


        for (int hauteur = 0; hauteur < plateau.length; hauteur++) {
            System.out.print(ANSI_COLOR + hauteur + ANSI_RESET + "  ");
            for (int largeur = 0; largeur < plateau.length; largeur++) {
                switch (plateau[hauteur][largeur]) {               // Choisi le pion correcte à afficher (ou vide)
                    case 1:
                        System.out.print(pionblanc);
                        break;
                    case 2:
                        System.out.print(dameblanche);
                        break;
                    case 3:
                        System.out.print(pionnoir);
                        break;
                    case 4:
                        System.out.print(damenoire);
                        break;
                    default:
                        System.out.print(" ");
                }
                System.out.print("  ");
            }
            System.out.print(ANSI_COLOR + "■" + ANSI_RESET);
            System.out.println();

        }
        for (int largeur = 0; largeur < plateau.length + 2; largeur++)
            System.out.print(ANSI_COLOR + "■  " + ANSI_RESET);
        System.out.println();

        System.out.println("\n══════════════════════════════════\n");
    }
}