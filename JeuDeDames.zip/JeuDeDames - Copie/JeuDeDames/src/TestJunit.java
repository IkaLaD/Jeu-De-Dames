import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class TestJunit
{
    @Test
    public final void coordonnéeValide()
    {
        // --Coordonée En Dehors Du Damier

        Case c1 = new Case(-1,-1);
        Case c2 = new Case(8,8);
        Case c3 = new Case(-1,1);
        Case c4 = new Case(1,-1);
        Case c5 = new Case(7,7);
        Case c6 = new Case(0,0);


        assertFalse(JeuDeDame.positionValide(c1));
        assertFalse(JeuDeDame.positionValide(c2));
        assertFalse(JeuDeDame.positionValide(c3));
        assertFalse(JeuDeDame.positionValide(c4));
        assertFalse(JeuDeDame.positionValide(c5));
        assertFalse(JeuDeDame.positionValide(c6));

        // --Coordonée sur case blanche

        Case c10 = new Case(6,6);
        Case c11 = new Case(4,4);

        assertFalse(JeuDeDame.positionValide(c10));
        assertFalse(JeuDeDame.positionValide(c11));

        // --Coordonée sur case noir

        Case c7 = new Case(6,7);
        Case c8 = new Case(5,0);
        Case c9 = new Case(1,0);


        assertTrue(JeuDeDame.positionValide(c7));
        assertTrue(JeuDeDame.positionValide(c8));
        assertTrue(JeuDeDame.positionValide(c9));

    }

    @Test
    public final void  testDamePeuManger()
    {
        int[][] plat =
                {
                        {0,0,0,0,0,0,0,0,0,0},
                        {0,0,0,0,0,0,0,0,0,0},
                        {0,0,0,0,0,0,0,3,0,0},
                        {0,0,0,0,0,0,0,0,0,0},
                        {0,0,0,0,0,0,0,0,0,0},
                        {0,0,0,0,0,0,0,0,0,0},
                        {0,0,0,0,0,0,0,0,0,0},
                        {0,0,0,0,0,0,0,0,0,0},
                        {0,2,0,0,0,0,0,0,0,0},
                        {0,0,0,0,0,0,0,0,0,0}
                };


        assertTrue(JeuDeDame.peutPrendre(plat,new Case(1,8),1));

        int[][] plat2 =
                {
                        {0,0,0,0,0,0,0,0,0,0},
                        {0,2,0,0,0,0,0,0,0,0},
                        {0,0,0,0,0,0,0,3,0,0},
                        {0,0,0,0,0,0,0,0,0,0},
                        {0,0,0,0,0,0,0,0,0,0},
                        {0,0,0,0,0,3,0,0,0,0},
                        {0,0,0,0,0,0,0,0,0,0},
                        {0,0,0,0,0,0,0,0,0,0},
                        {0,2,0,0,0,0,0,0,0,0},
                        {0,0,0,0,0,0,0,0,0,0}
                };


        assertTrue(JeuDeDame.peutPrendre(plat2,new Case(1,1),1));
    }

    @Test
    public final void  PionPeutManger() {
        int[][] plat =
                {
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 3, 0, 0, 0, 0, 0, 0},
                        {0, 0, 1, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
                };


        assertTrue(JeuDeDame.peutPrendre(plat, new Case(2, 7), 1));

        int[][] plat2 =
                {
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 1, 0, 0, 0, 0, 0, 0, 0},
                        {0, 3, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
                };


        assertTrue(JeuDeDame.peutPrendre(plat2, new Case(2, 7), 1));


        int[][] plat3 =
                {
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 3, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 1, 0, 0, 0, 0, 0, 0, 0, 0},
                        {1, 0, 3, 0, 1, 0, 0, 0, 0, 0},
                        {0, 1, 0, 1, 0, 1, 0, 0, 0, 0},
                        {1, 0, 1, 0, 1, 0, 0, 0, 0, 0}
                };


        assertTrue(JeuDeDame.peutPrendre(plat3, new Case(2, 7), 2));
    }

    @Test
    public final void  peutBouger() {
        int[][] plat =
                {
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 1, 0, 0, 0, 0, 0, 0, 0},
                        {0, 3, 0, 3, 0, 0, 0, 0, 0, 0},
                        {3, 0, 0, 0, 3, 0, 0, 0, 0, 0}
                };


        assertFalse(JeuDeDame.peutBouger(plat, new Case(2, 7), 1));

        int[][] plat2 =
                {
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 1, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
                };


        assertTrue(JeuDeDame.peutBouger(plat2, new Case(2, 7), 1));


        int[][] plat3 =
                {
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 1, 0, 0, 0, 0, 0, 0, 0},
                        {0, 1, 0, 1, 0, 0, 0, 0, 0, 0},
                        {2, 0, 2, 0, 2, 0, 0, 0, 0, 0}
                };


        assertFalse(JeuDeDame.peutBouger(plat3, new Case(2, 7), 1));
    }

    @Test
    public final void  personneNePeutManger()
    {
        int[][] plat1 =
                {
                        {0,0,0,0,0,0,0,0,0,0},
                        {0,0,0,0,0,0,0,0,0,0},
                        {0,0,0,0,0,0,0,3,0,0},
                        {0,0,0,0,0,0,3,0,0,0},
                        {0,0,0,0,0,3,0,0,0,0},
                        {0,0,0,0,1,0,0,0,0,0},
                        {0,0,0,0,0,0,0,0,0,0},
                        {0,0,2,0,0,0,1,0,0,0},
                        {0,0,0,0,0,0,2,0,0,0},
                        {0,0,2,0,0,2,0,0,0,0}
                };


        assertTrue(JeuDeDame.nePeutPasPrendre(plat1,1));



        int[][] plat =
                {
                        {0,0,0,0,0,0,0,0,0,0},
                        {0,0,0,0,0,0,0,0,0,0},
                        {0,0,0,0,0,0,0,3,0,0},
                        {0,0,0,0,0,0,3,0,0,0},
                        {0,0,0,0,0,3,0,0,0,0},
                        {0,0,0,0,1,0,0,0,0,0},
                        {0,0,0,0,0,0,0,3,0,0},
                        {0,0,2,0,0,0,1,0,0,0},
                        {0,0,0,0,0,0,2,0,0,0},
                        {0,0,2,0,0,2,0,0,0,0}
                };


        assertFalse(JeuDeDame.nePeutPasPrendre(plat,1));
    }


    @Test

    public final void peutSeDeplacerSansManger()
    {
        int[][] plat1 =
                {
                        {0,0,0,0,0,0,0,0,0,0},
                        {0,0,0,0,0,0,0,0,0,0},
                        {0,0,0,0,0,0,0,3,0,0},
                        {0,0,0,0,0,0,3,0,0,0},
                        {0,0,0,0,0,3,0,0,0,0},
                        {0,0,0,0,1,0,0,0,0,0},
                        {0,0,0,0,0,0,0,0,0,0},
                        {0,0,2,0,0,0,1,0,0,0},
                        {0,0,0,0,0,0,2,0,0,0},
                        {0,0,2,0,0,2,0,0,0,0}
                };


        assertTrue(JeuDeDame.peutBouger(plat1,new Case(2,9),1));

        int[][] plat =
                {
                        {0,0,0,0,0,0,0,0,0,0},
                        {0,0,0,0,0,0,0,0,0,0},
                        {0,0,0,0,0,0,0,3,0,0},
                        {0,0,0,0,0,0,3,0,0,0},
                        {0,0,0,0,0,3,0,0,0,0},
                        {0,0,0,0,1,0,0,0,0,0},
                        {0,0,0,0,0,0,0,3,0,0},
                        {0,0,2,0,0,0,1,0,0,0},
                        {2,2,0,0,0,0,2,0,0,0},
                        {2,0,2,0,0,2,0,0,0,0}
                };


        assertFalse(JeuDeDame.peutBouger(plat,new Case(0,9),1));

        int[][] plat2 =
                {
                        {0,0,0,0,0,0,0,0,0,0},
                        {0,0,0,0,0,0,0,0,0,0},
                        {0,0,0,0,0,0,0,0,0,0},
                        {0,0,0,0,0,0,0,0,0,0},
                        {0,0,0,0,0,0,0,0,0,0},
                        {0,0,0,0,0,0,0,0,0,0},
                        {0,1,0,1,0,0,0,0,0,0},
                        {0,0,2,0,0,0,0,0,0,0},
                        {0,1,0,0,0,0,0,0,0,0},
                        {0,0,0,0,0,0,0,0,0,0}
                };

        assertTrue(JeuDeDame.peutBouger(plat2,new Case(2,7),1));
    }

    @Test
    public final void recupererLongueurPlusGrandCheminPion(){

        Case c1 = new Case(0,0);
        int[][] plat =
                {
                        {1,0,0,0,0,0,0,0,0,3},
                        {0,3,0,0,0,3,0,0,0,0},
                        {0,0,0,0,0,0,0,0,0,0},
                        {0,0,0,3,0,0,0,3,0,0},
                        {0,0,0,0,0,0,0,0,0,0},
                        {0,0,0,0,0,3,0,3,0,0},
                        {0,0,0,0,0,0,0,0,0,0},
                        {0,3,0,0,0,0,0,3,0,0},
                        {0,0,3,0,0,0,0,3,0,0},
                        {0,0,0,0,0,0,0,0,0,0}
                };
        // Un chemin
        assertEquals(6, JeuDeDame.recupererLongueurPlusGrandChemin(plat, c1, 1, 1));

        Case c2 = new Case(0,0);
        int[][] plat2 =
                {
                        {1,0,0,0,0,0,0,0,0,0},
                        {0,3,0,0,0,0,0,0,0,0},
                        {0,0,0,0,0,0,0,3,0,0},
                        {0,0,0,3,0,0,3,0,0,1},
                        {1,0,0,0,0,0,0,0,0,0},
                        {0,0,0,0,0,3,0,0,0,0},
                        {1,0,0,0,0,0,0,0,0,0},
                        {0,0,3,0,0,0,0,3,0,0},
                        {0,0,0,0,0,0,0,0,0,0},
                        {0,0,0,0,0,1,0,0,0,1}
                };

        // Deux chemins différentes tailes
        assertEquals(4, JeuDeDame.recupererLongueurPlusGrandChemin(plat2, c2, 1, 1));

        Case c3 = new Case(0,0);
        int[][] plat3 =
                {
                        {1,0,0,0,0,0,0,0,0,0},
                        {0,3,0,0,0,0,0,3,0,0},
                        {0,0,0,0,0,0,0,0,0,0},
                        {0,3,0,3,0,3,0,0,0,0},
                        {1,0,0,0,0,0,0,0,0,0},
                        {0,0,0,0,0,3,0,0,1,0},
                        {0,0,0,0,0,0,0,0,0,0},
                        {0,0,0,3,0,3,0,0,0,0},
                        {1,0,0,0,0,0,0,0,1,0},
                        {0,0,0,1,0,0,0,0,0,0}
                };

        // Trois chemins différentes tailles
        assertEquals(5, JeuDeDame.recupererLongueurPlusGrandChemin(plat3, c3, 1, 1));

    }

    @Test
    public final void recupererLongueurPlusGrandCheminDame() {

        Case c1 = new Case(3, 2);
        int[][] plat =
                {
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 3, 0, 0, 0, 0, 0},
                        {0, 0, 0, 2, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 3, 0, 0, 0},
                        {0, 0, 0, 3, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 3, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
                };

        assertEquals(4, JeuDeDame.recupererLongueurPlusGrandChemin(plat, c1, 1, 2));

        Case c2 = new Case(0, 0);
        int[][] plat2 =
                {
                        {2, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 3, 0, 0},
                        {0, 0, 3, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 3, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 3, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
                };

        assertEquals(3, JeuDeDame.recupererLongueurPlusGrandChemin(plat2, c2, 1, 2));

        Case c3 = new Case(0, 0);
        int[][] plat3 =
                {
                        {2, 0, 0, 0, 0, 0, 0, 0, 1, 0},
                        {0, 0, 0, 0, 0, 0, 0, 3, 0, 0},
                        {0, 0, 3, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 3, 0, 0, 0, 0},
                        {0, 0, 0, 0, 1, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 3, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
                };

        assertEquals(1, JeuDeDame.recupererLongueurPlusGrandChemin(plat3, c3, 1, 2));
    }

    @Test
    public final void estLunDesPlusLongChemin(){

        // 2 chemins différentes tailles
        Case c1 = new Case(1,1);
        int[][] plat =
                {
                        {0,0,0,0,0,0,0,0,0,1},
                        {0,1,0,0,0,0,0,0,0,0},
                        {0,0,3,0,0,0,0,3,0,0},
                        {0,0,0,0,0,0,0,0,0,0},
                        {0,0,3,0,0,3,0,0,3,0},
                        {0,0,0,0,0,0,0,0,0,0},
                        {0,0,3,0,0,0,0,0,0,0},
                        {0,0,0,0,0,0,0,0,0,0},
                        {0,0,0,0,3,0,3,0,0,0},
                        {0,0,0,0,0,0,0,1,0,0}
                };

        assertTrue(JeuDeDame.estLunDesPlusLongChemin(plat, c1, 1));

        // 2 chemins même taille
        Case c2 = new Case(1,1);
        int[][] plat2 =
                {
                        {0,0,0,0,0,0,0,0,0,1},
                        {0,1,0,0,0,0,0,0,3,0},
                        {0,0,3,0,0,0,0,0,0,0},
                        {0,0,0,0,0,0,3,0,0,0},
                        {0,0,0,0,3,0,0,0,0,0},
                        {0,0,0,0,0,0,0,0,0,0},
                        {0,0,0,0,0,0,0,0,0,0},
                        {0,0,0,0,0,0,0,0,0,0},
                        {0,0,0,0,0,0,0,0,0,0},
                        {0,0,0,0,0,0,0,0,0,0}
                };

        assertTrue(JeuDeDame.estLunDesPlusLongChemin(plat2, c2, 1));

        // 3 chemins différente taille
        Case c3 = new Case(1,9);
        int[][] plat3 =
                {
                        {0,0,0,0,0,0,0,0,0,1},
                        {0,0,0,0,0,0,0,0,3,0},
                        {0,0,3,0,0,0,0,0,0,0},
                        {0,0,0,0,0,0,0,0,0,0},
                        {0,0,0,0,3,0,0,0,0,0},
                        {0,0,0,0,0,0,0,0,0,0},
                        {0,0,0,0,3,0,0,0,3,0},
                        {0,0,0,0,0,0,0,0,0,0},
                        {0,0,3,0,0,0,0,0,3,0},
                        {0,1,0,0,0,0,0,0,0,1}
                };

        assertTrue(JeuDeDame.estLunDesPlusLongChemin(plat3, c3, 1));

    }
}