import java.util.Scanner;
public class Menu {

    public static void Menu(){
        Scanner sc = new Scanner(System.in);
        int choix=0;

        afficherMenu();
        System.out.print("\t\t>>");
        choix = sc.nextInt();
        while(choix < 1 || choix > 3){
            System.out.println("\t\tSélectionner un choix valide !");
            System.out.print("\t\t>>");
            choix = sc.nextInt();
        }

        switch (choix){
            case 1:
                DeroulePartie.startPartie();
                break;
            case 2:
                affichageReglesDuJeu();
                Menu();
                break;
        }
    }

    public static void affichagePresentation(){
        System.out.println(
                "\t\t   ╔════════════════════╗\n" +
                "\t\t   ║    Jeu De Dames    ║\n" +
                "\t\t   ╚════════════════════╝\n" +
                "\t\tCrée par :\n" +
                "\t\tThomas GOMES / Mohamed BENYOUB");
    }

    public static void affichageReglesDuJeu(){
        System.out.println(
                "\t\t╔═══════════════════════════════════════════════════════════════════════════════════════════════╗\n" +
                "\t\t║                                         Règles du jeu                                         ║\n" +
                "\t\t╠═══════════════════════════════════════════════════════════════════════════════════════════════╣\n" +
                "\t\t║                                                                                               ║\n" +
                "\t\t║  Le jeu de dames développé içi suit les règles du jeu de dames international :                ║\n" +
                "\t\t║                                                                                               ║\n" +
                "\t\t║  1. Le plateau de jeu : Le jeu se joue sur un damier de 10x10 cases avec des cases            ║\n" +
                "\t\t║  claires et foncées . Chaque joueur a ses pièces sur les cases noires de sa rangée            ║\n" +
                "\t\t║  la plus proche.                                                                              ║\n" +
                "\t\t║                                                                                               ║\n" +
                "\t\t║  2. Les pièces : Chaque joueur commence avec 20 pièces de couleur soit claire, soit foncée.   ║\n" +
                "\t\t║  Les pièces se déplacent en diagonale sur les cases vides uniquement.                         ║\n" +
                "\t\t║                                                                                               ║\n" +
                "\t\t║  3. Le déplacement : Les pièces se déplacent en avant diagonalement d'une case. Lorsqu'une    ║\n" +
                "\t\t║  pièce atteint la dernière rangée de l'adversaire, elle devient une 'dame' et peut se         ║\n" +
                "\t\t║  déplacer en diagonale dans toutes les directions à peu importe la distance.                  ║\n" +
                "\t\t║                                                                                               ║\n" +
                "\t\t║  4. La capture : Pour capturer une pièce adverse, une pièce doit sauter par-dessus elle,      ║\n" +
                "\t\t║  en avant ou en arrière, si la case suivante est vide. La pièce adverse capturée est          ║\n" +
                "\t\t║  retirée du jeu.                                                                              ║\n" +
                "\t\t║                                                                                               ║\n" +
                "\t\t║  5. Les sauts multiples : Si une pièce effectue une capture et atterrit sur une position      ║\n" +
                "\t\t║  où elle peut capturer à nouveau, elle doit continuer à le faire jusqu'à ce que tous les      ║\n" +
                "\t\t║  sauts possibles soient effectués. Les dames peuvent également effectuer des sauts multiples. ║\n" +
                "\t\t║  Important ! La capture permettant de récupérer le plus de pions adverse sur un tour est      ║\n" +
                "\t\t║  obligatoire. Si la capture que vous effectuez ne permet pas cette capture maximal, le jeu    ║\n" +
                "\t\t║  vous en avertira.                                                                            ║\n" +
                "\t\t║                                                                                               ║\n" +
                "\t\t║  6. Le but du jeu : L'objectif est de capturer toutes les pièces de l'adversaire ou de        ║\n" +
                "\t\t║  bloquer toutes leurs pièces de manière à les rendre incapables de bouger.                    ║\n" +
                "\t\t║                                                                                               ║\n" +
                "\t\t║  7. Fin du jeu : Le jeu se termine lorsque l'un des joueurs atteint son objectif, que         ║\n" +
                "\t\t║  ce soit en capturant toutes les pièces de l'adversaire ou en bloquant toutes leurs           ║\n" +
                "\t\t║  pièces. Au delà de 25 tours sans prise, le jeu s'arrête sur une égalité.                     ║\n" +
                "\t\t║                                                                                               ║\n" +
                "\t\t╚═══════════════════════════════════════════════════════════════════════════════════════════════╝");
    }

    public static void afficherMenu(){
        System.out.println(
                "\t\t╔══════════════════════════╗\n" +
                "\t\t║           Menu           ║\n" +
                "\t\t╠══════════════════════════╣\n" +
                "\t\t║ 1. Lancer une partie     ║\n" +
                "\t\t║ 2. Règles                ║\n" +
                "\t\t║ 3. Quitter le jeu        ║\n" +
                "\t\t╚══════════════════════════╝\n"
                );
    }
}
