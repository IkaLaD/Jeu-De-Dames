import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class DeroulePartie {

    /***
     * Ici est le main de la partie, avec des actions décomposer en un arbre de if/else pour chaque type de situation.
     */
    public static void startPartie()
    {
        List<String> joueurs;
        joueurs = initJoueur();
        int[][] plateau = JeuDeDame.initalisation(10);
        espace(30);
        int couleur;
        Case coStart;
        Case coEnd;
        String rouge = "\u001B[31m";
        String reset = "\u001B[0m";

        int tourSansPrise = 0;
        do // boucle qui sert a joué tant que c'est pas la fin
        {
            for (int i = 1 ; i >= 0 ; i--)
            {
                espace(30);
                couleur = i+1;
                Affichage.plateau(plateau, couleur);
                System.out.println(joueurs.get(i)+", à toi de jouer !");

                boolean coupValide=false;

                // Vérifie que les coordonées de départ et d'arrivés vont être un coup légale
                // REFERENCE : STRUCTURE BRANCHE IMAGE
                while(!coupValide) {
                    coStart = recupCoordonne("le pion que vous souhaitez déplacer.");

                    if (JeuDeDame.positionVide(plateau, coStart)){
                        espace(30);
                        Affichage.plateau(plateau, couleur);
                        System.out.println(rouge+"Sélectionnez une case non vide !"+reset);
                    }
                    else if ( JeuDeDame.recupCouleur(plateau, coStart) != couleur){
                        espace(30);
                        Affichage.plateau(plateau, couleur);
                        System.out.println(rouge+"Sélectionnez une case comportant l'un de vos pions !"+reset);
                    }
                    else if(!JeuDeDame.peutBouger(plateau, coStart, couleur) && !JeuDeDame.peutPrendre(plateau, coStart, couleur)){
                        espace(30);
                        Affichage.plateau(plateau, couleur);
                        System.out.println(rouge+"Sélectionnez un de vos pions qui peut se déplacer !"+reset);
                    }
                    else{
                        if(JeuDeDame.peutPrendre(plateau, coStart, couleur)){
                            if(JeuDeDame.estLunDesPlusLongChemin(JeuDeDame.copie(plateau), coStart, couleur)){
                                while(!coupValide) {
                                    do {
                                        coEnd = recupCoordonne(" vous souhaitez déplacer le pion que vous avez séléctionné.");

                                        if (!JeuDeDame.positionVide(plateau, coEnd)) {
                                            espace(30);
                                            Affichage.plateau(plateau, couleur);
                                            System.out.println(rouge+"Sélectionnez une position d'arrivée vide !"+reset);
                                        }
                                        else {
                                            if(JeuDeDame.deplacementLogique(plateau, coStart, coEnd, couleur)) {
                                                coupValide=false;
                                                List<Case> correcte = JeuDeDame.recupererProchaineCasePlusGrandChemin(JeuDeDame.copie(plateau), coStart, couleur, JeuDeDame.quelEstLePion(plateau, coStart));
                                                for (Case c : correcte) {
                                                    if (coEnd.getLigne() == c.getLigne() && coEnd.getColonne() == c.getColonne()) {
                                                        JeuDeDame.deplacePion(plateau, coStart, coEnd, couleur, true);
                                                        JeuDeDame.transformationDame(plateau);
                                                        coStart = coEnd;
                                                        tourSansPrise = 0;
                                                        coupValide = true;
                                                    }
                                                }
                                                if (!coupValide) {
                                                    espace(30);
                                                    Affichage.plateau(plateau, couleur);
                                                    System.out.println(rouge + "Déplacez vôtre pion de manière à faire la prise la plus longue possible !" + reset);
                                                }
                                            }
                                            else {
                                                espace(30);
                                                Affichage.plateau(plateau, couleur);
                                                System.out.println(rouge + "Sélectionnez un déplacement cohérent !" + reset);
                                            }
                                        }
                                        if(coupValide && JeuDeDame.peutPrendre(plateau, coStart, couleur))
                                            Affichage.plateau(plateau, couleur);
                                    }while(coupValide && JeuDeDame.peutPrendre(plateau, coStart, couleur));
                                }
                            }
                            else {
                                espace(30);
                                Affichage.plateau(plateau, couleur);
                                System.out.println(rouge+"Ce pion ne permet pas de manger le plus de pions que vous pouvez sur ce tour, sélectionnez ceux qui peuvent prendre le maximum."+reset);
                            }
                        }
                        else{
                            if (JeuDeDame.nePeutPasPrendre(plateau, couleur)) {
                                while (!coupValide) {
                                    coEnd = recupCoordonne("l'arrivez du coup que vous souhaitez faire.");
                                    if (JeuDeDame.positionVide(plateau, coEnd)) {
                                        if (JeuDeDame.deplacementLogique(plateau, coStart, coEnd, couleur)) {
                                            tourSansPrise++;
                                            JeuDeDame.deplacePion(plateau, coStart, coEnd, couleur, false);
                                            JeuDeDame.transformationDame(plateau);
                                            coupValide = true;
                                        }
                                        else {
                                            espace(30);
                                            Affichage.plateau(plateau, couleur);
                                            System.out.println(rouge+"Sélectionnez un déplacement cohérent !"+reset);
                                        }
                                    } else {
                                        espace(30);
                                        Affichage.plateau(plateau, couleur);
                                        System.out.println(rouge+"Sélectionnez une case ne comportant pas de pions !"+reset);
                                    }
                                }
                            }
                            else {
                                espace(30);
                                Affichage.plateau(plateau, couleur);
                                System.out.println(rouge+"Vous avez des pions à dispositions qui permettent de prendre un pion ennemi, sélectionnez l'un d'entre eux"+reset);
                            }
                        }
                    }
                }
                if(JeuDeDame.partieFini(plateau))
                    break;
            }
            if(JeuDeDame.partieFini(plateau))
                break;

        }while (tourSansPrise < 25 && !JeuDeDame.partieFini(plateau));
        JeuDeDame.quiAGagne(plateau, joueurs);
    }

    public static List<String> initJoueur()
    {
        List<String> players = new ArrayList<>();
        Scanner sc = new Scanner(System.in);
        String pseudo1;
        String pseudo2;

        do {
            System.out.print("\t\tJoueur noir entrez votre pseudo.\n\t\tLe pseudo doit faire au moins 3 caractères\n\t\t>>");
            pseudo1 = sc.nextLine();
        } while (pseudo1.length() < 3);

        do {
            System.out.print("\t\tJoueur blanc entrez votre pseudo.\n\t\tLe pseudo doit faire au moins 3 caractères et dois être différant du joueur noir\n\t\t>>");
            pseudo2 = sc.nextLine();
        } while (pseudo2.length() < 3 || pseudo1.equals(pseudo2));

        players.add(pseudo1);
        players.add(pseudo2);

        return players;
    }

    public static Case recupCoordonne(String s)
    {
        Scanner sc = new Scanner(System.in);
        Case position;
        int x = 0,y = 0;

        do // boucle pour recuperer le x de la position de depart
        {
            System.out.println("Entrez la colonne ou se situe "+s+"..");

            try
            {
                x = sc.nextInt();
            }
            catch (IllegalArgumentException e)
            {
                sc.next();
                System.out.println("Entrez seulement un ENTIER");
            }

        } while (x > 9 || x < 0);

        do // boucle pour recuperer le y de la position de depart
        {
            System.out.println("Entrez la ligne ou se situe "+s+ "..");

            try
            {
                y = sc.nextInt();
            }
            catch (IllegalArgumentException e)
            {
                sc.next();
                System.out.println("Entrez seulement un ENTIER");
            }

        } while (y > 9 || y < 0);


        position = new Case(x,y);

        return position;
    }

    public static void espace(int ligne){
        for(int i = 0 ; i < ligne ; i++)
            System.out.println();
    }
}
